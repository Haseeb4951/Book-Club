package com.example.labs2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);

        TextView textViewWelcomeMessage = findViewById(R.id.text_welcome_message);

        textViewWelcomeMessage.setText("Welcome, User!");
    }
}

